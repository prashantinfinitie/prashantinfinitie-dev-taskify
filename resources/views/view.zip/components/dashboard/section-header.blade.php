@props(['title' => ''])

<div class="d-flex justify-content-between">
    <h4 class="fw-bold">{{ $title }}</h4>
</div>
